These gerbers are in the RS-274X format.

--------------
 Gerber Files
--------------
art_param.txt -- Gerber parameters for interpretation of RS274X layer data
fab.art       -- Printed Circuit Board fabrication notes
TOP.art       -- Top etch layer 1
BOTTOM.art    -- Bottom etch layer 2
psm.art       -- Primary-side Solder Mask layer 1
pss.art       -- Primary-side Silk Screen layer 1
psp.art       -- Primary-side Solder Paste layer 1
passy.art     -- Primary-side Assembly layer 1
ssm.art       -- Secondary-side Solder Mask layer 2
sss.art       -- Secondary-side Silk Screen layer 2
ssp.art       -- Secondary-side Solder Paste layer 2
sci.art       -- Secondary-side Carbon ink layer 2
sassy.art     -- Secondary-side Assembly layer 2	

----------------------------------------
 Drawings (PDF)
----------------------------------------
121-26500_B.pdf -- Primary-side &  Secondary-side Assembly drawing
PDC-9265_B.pdf --  Drill Drawing & Board Layers


-------------
 Drill Files
-------------
nc_param.txt  -- Drill list parameters
ncdrill1.tap  -- Tape File
nctape.log    -- Drill list


----------------------
 Pick and Place Files
----------------------
PDC-9265-B-INSERT -- Components list including pick-and-place locations


-------------------------------
Known or Outstanding DRC Errors
-------------------------------
There is 1 known/outstanding DRC error present in the layout.
(2290.0 1375.0)		Header J2 and J3 place bounds overlap


Instructions to view gerbers:

  GraphiCode, Inc. provides a freeware gerber viewer, GC-Prevue, available
  for download at the following URL:

  http://www.graphicode.com/pages/products.cfm#_Toc5 

  Once this application is installed you can view the *.art files by
  using the "File | Import" function. 

  Cypress uses a .art extension for gerber files. Gerber files are ASCII
  text and are easily identified to someone "learned in the art."